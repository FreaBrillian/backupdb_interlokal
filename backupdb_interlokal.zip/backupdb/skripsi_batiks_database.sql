

CREATE TABLE `barang` (
  `id` varchar(250) NOT NULL,
  `id_kategori` varchar(250) NOT NULL,
  `nama_supplier` varchar(250) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `file` varchar(250) NOT NULL,
  `jumlah_pcs` tinyint(4) NOT NULL,
  `harga` int(11) NOT NULL,
  `pcs` int(11) NOT NULL,
  `box` int(11) NOT NULL,
  `status` enum('a','h') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kategori` (`id_kategori`),
  CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO barang VALUES("B-20231002150721-1","K-20231002145047-1","Toko A","Kemeja Batik Lengan Panjang","f9d24cc493bee21ed4ffaebddb796568.jpg","20","150000","38","8","a");
INSERT INTO barang VALUES("B-20231027093610-1","K-20231002150033-1","Toko B","Celana Angkle Pants","31ead1de4eede84b7a7ea422a6ca51f3.jpg","20","100000","20","19","a");
INSERT INTO barang VALUES("B-20231206090043-1","K-20231206085319-1","PT Primatex","Kain Batik Jlamprang","4e46fc2c479b0bf70ebb4df080ec86e3.jpg","20","50000","51","9","a");
INSERT INTO barang VALUES("B-20231207090037-1","K-20231206085319-1","PT Pismatex","kain batik percobaan","82acc62707d4002f3c80c8ed1fd16f88.jpg","20","50000","80","3","a");
INSERT INTO barang VALUES("B-20231209072833-1","K-20231209072741-1","PT Aneka Jaya","Tas Batik Megamendung","94d17d4da1d71310c6cc7132b8d237f6.jpg","20","100000","9","5","a");



CREATE TABLE `kategori` (
  `id` varchar(250) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `file` varchar(250) NOT NULL,
  `status` enum('a','h') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO kategori VALUES("K-20231002145047-1","Pakaian Dewasa","8ff73b3f68bb7299b366f4399e984bbd.svg","a");
INSERT INTO kategori VALUES("K-20231002150033-1","Celana Dewasa","51c31624777788adc3ea2a3a52a5622f.svg","a");
INSERT INTO kategori VALUES("K-20231206085319-1","Kain Batik","a5329fd4401ee0e390935761eb53b9cb.svg","a");
INSERT INTO kategori VALUES("K-20231209072741-1","Aksesoris","47ddef36fb678a2d94334b6ded067865.svg","a");



CREATE TABLE `keranjang` (
  `id` varchar(250) NOT NULL,
  `id_pengguna` varchar(250) NOT NULL,
  `id_barang` varchar(250) NOT NULL,
  `jumlah` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pengguna` (`id_pengguna`),
  CONSTRAINT `keranjang_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `pengguna` (
  `id` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `hak_akses` enum('1','2','3') NOT NULL COMMENT '1=user,2=kasir,3=kepala',
  `status` enum('a','h') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO pengguna VALUES("PG-20231002114104-1","kasir","de28f8f7998f23ab4194b51a6029416f","Kasir Toko","2","a");
INSERT INTO pengguna VALUES("PG-20231002160625-1","sul","75890dc9e8aefca7a8a41eeb47dfc59e","sulaiman","1","a");



CREATE TABLE `transaksi` (
  `id` varchar(250) NOT NULL,
  `id_pengguna` varchar(250) DEFAULT NULL,
  `status` enum('bayar','menunggu','dikemas','dikirim','diterima') NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `tanggal_terima` date DEFAULT NULL,
  `total_transaksi` int(11) NOT NULL,
  `tipe` enum('online','ta','offline') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pengguna` (`id_pengguna`),
  CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO transaksi VALUES("TR-20231027110602-1","","diterima","2023-10-27","","150000","offline");
INSERT INTO transaksi VALUES("TR-20231027111345-1","","diterima","2023-10-27","","150000","offline");
INSERT INTO transaksi VALUES("TR-20231206095307-1","","diterima","2023-12-06","","250000","offline");
INSERT INTO transaksi VALUES("TR-20231206133001-1","PG-20231002160625-1","diterima","2023-12-06","","50000","ta");
INSERT INTO transaksi VALUES("TR-20231206154035-1","","diterima","2023-12-06","","50000","offline");
INSERT INTO transaksi VALUES("TR-20231206154210-1","PG-20231002160625-1","diterima","2023-12-06","2023-12-06","100000","ta");
INSERT INTO transaksi VALUES("TR-20231209073217-1","PG-20231002160625-1","diterima","2023-12-09","2023-12-09","100000","ta");



CREATE TABLE `transaksi_detail` (
  `id` varchar(250) NOT NULL,
  `id_transaksi` varchar(250) NOT NULL,
  `id_barang` varchar(250) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO transaksi_detail VALUES("TRD-20231027110602-1","TR-20231027110602-1","B-20231002150721-1","150000","1");
INSERT INTO transaksi_detail VALUES("TRD-20231027111345-1","TR-20231027111345-1","B-20231002150721-1","150000","1");
INSERT INTO transaksi_detail VALUES("TRD-20231206095307-1","TR-20231206095307-1","B-20231206090043-1","50000","5");
INSERT INTO transaksi_detail VALUES("TRD-20231206133001-1","TR-20231206133001-1","B-20231206090043-1","50000","1");
INSERT INTO transaksi_detail VALUES("TRD-20231206154035-1","TR-20231206154035-1","B-20231206090043-1","50000","1");
INSERT INTO transaksi_detail VALUES("TRD-20231206154210-1","TR-20231206154210-1","B-20231206090043-1","50000","2");
INSERT INTO transaksi_detail VALUES("TRD-20231209073217-1","TR-20231209073217-1","B-20231209072833-1","100000","1");

