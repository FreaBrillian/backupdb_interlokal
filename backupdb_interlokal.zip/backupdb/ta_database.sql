

CREATE TABLE `tabel_akun` (
  `kode_akun` int(11) NOT NULL,
  `nama_akun` varchar(50) NOT NULL,
  `saldo_awal` int(15) NOT NULL,
  `saldo_akhir` int(15) NOT NULL,
  `jenis_akun` enum('a','p') NOT NULL,
  PRIMARY KEY (`kode_akun`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_akun VALUES("101","Kas","0","0","a");
INSERT INTO tabel_akun VALUES("102","Bank","0","0","a");
INSERT INTO tabel_akun VALUES("103","Persediaan ","0","0","a");
INSERT INTO tabel_akun VALUES("201","Modal","0","0","p");
INSERT INTO tabel_akun VALUES("401","Penjualan","0","2000000","p");
INSERT INTO tabel_akun VALUES("402","Potongan Penjualan","0","0","a");
INSERT INTO tabel_akun VALUES("403","Retur penjualan","0","2000000","a");



CREATE TABLE `tabel_barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `imei` varchar(30) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `spesifikasi` varchar(50) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `id_merk` int(11) NOT NULL,
  `stok` enum('1','0') NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_barang VALUES("1","asdad1212","hasancoba","hideng","100000","500000","1","1");



CREATE TABLE `tabel_biaya` (
  `id_biaya` int(5) NOT NULL AUTO_INCREMENT,
  `biaya` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  PRIMARY KEY (`id_biaya`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_biaya VALUES("1","gaji","2000");
INSERT INTO tabel_biaya VALUES("2","pembelian","720000");
INSERT INTO tabel_biaya VALUES("3","lain-lain","405000");



CREATE TABLE `tabel_customer` (
  `id_customer` int(11) NOT NULL AUTO_INCREMENT,
  `nama_customer` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  PRIMARY KEY (`id_customer`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_customer VALUES("6","Furqon Hidayat","082322744798","Ambokembang gg 2 Kedungwuni Pekalongan");
INSERT INTO tabel_customer VALUES("7","aulia safarani","085728191445","Pekajangan gg 15 no72 Kedusngwuni Pekalongan");



CREATE TABLE `tabel_jurnal_detail` (
  `id_jurnal_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_jurnal` varchar(50) NOT NULL,
  `kode_akun` int(5) NOT NULL,
  `debit` int(15) NOT NULL,
  `kredit` int(15) NOT NULL,
  PRIMARY KEY (`id_jurnal_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_jurnal_detail VALUES("1","JU-130310-48","101","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("2","JU-130310-48","401","0","500000");
INSERT INTO tabel_jurnal_detail VALUES("3","JU-360310-49","403","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("4","JU-360310-49","101","0","500000");
INSERT INTO tabel_jurnal_detail VALUES("5","JU-140310-53","101","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("6","JU-140310-53","401","0","500000");
INSERT INTO tabel_jurnal_detail VALUES("7","JU-340310-54","403","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("8","JU-340310-54","101","0","500000");
INSERT INTO tabel_jurnal_detail VALUES("9","JU-010410-17","101","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("10","JU-010410-17","401","0","500000");
INSERT INTO tabel_jurnal_detail VALUES("11","JU-360510-18","403","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("12","JU-360510-18","101","0","500000");
INSERT INTO tabel_jurnal_detail VALUES("13","JU-020410-28","101","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("14","JU-020410-28","401","0","500000");
INSERT INTO tabel_jurnal_detail VALUES("15","JU-080410-31","403","500000","0");
INSERT INTO tabel_jurnal_detail VALUES("16","JU-080410-31","101","0","500000");



CREATE TABLE `tabel_jurnal_header` (
  `id_jurnal` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `no_bukti` varchar(100) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `status` enum('1','0') NOT NULL COMMENT '1=sudah,0=belum',
  PRIMARY KEY (`id_jurnal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_jurnal_header VALUES("JU-010410-17","2023-10-17","PJ-172023101700","Penjualan Tunai","1");
INSERT INTO tabel_jurnal_header VALUES("JU-020410-28","2023-10-18","PJ-182023102802","Penjualan Tunai","1");
INSERT INTO tabel_jurnal_header VALUES("JU-080410-31","2023-10-18","PJ-182023102802","Retur Penjualan","1");
INSERT INTO tabel_jurnal_header VALUES("JU-130310-48","2023-10-17","PJ-172023104813","Penjualan Tunai","1");
INSERT INTO tabel_jurnal_header VALUES("JU-140310-53","2023-10-17","PJ-172023105314","Penjualan Tunai","1");
INSERT INTO tabel_jurnal_header VALUES("JU-340310-54","2023-10-17","PJ-172023105314","Retur Penjualan","1");
INSERT INTO tabel_jurnal_header VALUES("JU-360310-49","2023-10-17","PJ-172023104813","Retur Penjualan","1");
INSERT INTO tabel_jurnal_header VALUES("JU-360510-18","2023-10-17","PJ-172023101700","Retur Penjualan","1");



CREATE TABLE `tabel_keranjang` (
  `id_barang` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `tabel_merk` (
  `id_merk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_merk` varchar(50) NOT NULL,
  PRIMARY KEY (`id_merk`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_merk VALUES("1","iPhone");
INSERT INTO tabel_merk VALUES("2","Samsung");
INSERT INTO tabel_merk VALUES("3","Google Pixel");
INSERT INTO tabel_merk VALUES("4","Huawei");



CREATE TABLE `tabel_pengguna` (
  `id_pengguna` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `hak_akses` enum('a','o') NOT NULL,
  `nama_lengkap` varchar(20) NOT NULL,
  PRIMARY KEY (`id_pengguna`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_pengguna VALUES("10","aulia","d7afde3e7059cd0a0fe09eec4b0008cd","a","aulia");
INSERT INTO tabel_pengguna VALUES("12","admin","0192023a7bbd73250516f069df18b500","a","Aulia Safarani");



CREATE TABLE `tabel_penjualan` (
  `id_penjualan` varchar(100) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `tgl_penjualan` date NOT NULL,
  `waktu_penjualan` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total_penjualan` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `jenis_bayar` enum('c','t') NOT NULL,
  `potongan_penjualan` int(11) NOT NULL,
  PRIMARY KEY (`id_penjualan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_penjualan VALUES("PJ-172023101700","6","2023-10-17","0000-00-00 00:00:00","500000","12","c","0");
INSERT INTO tabel_penjualan VALUES("PJ-172023104813","6","2023-10-17","0000-00-00 00:00:00","500000","12","c","0");
INSERT INTO tabel_penjualan VALUES("PJ-172023105314","6","2023-10-17","0000-00-00 00:00:00","500000","12","c","0");
INSERT INTO tabel_penjualan VALUES("PJ-182023102802","6","2023-10-18","0000-00-00 00:00:00","500000","12","c","0");



CREATE TABLE `tabel_penjualan_detail` (
  `id_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_penjualan` varchar(100) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `retur` enum('1','0') NOT NULL,
  PRIMARY KEY (`id_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO tabel_penjualan_detail VALUES("1","PJ-172023104813","1","0","100000","500000","1");
INSERT INTO tabel_penjualan_detail VALUES("2","PJ-172023105314","1","0","100000","500000","1");
INSERT INTO tabel_penjualan_detail VALUES("3","PJ-172023101700","1","0","100000","500000","1");
INSERT INTO tabel_penjualan_detail VALUES("4","PJ-182023102802","1","0","100000","500000","1");

