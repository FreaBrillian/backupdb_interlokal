

CREATE TABLE `akun` (
  `akun_id` int(11) NOT NULL,
  `nama_akun` varchar(100) NOT NULL,
  `saldo_awal` bigint(20) NOT NULL,
  `saldo_akhir` bigint(20) NOT NULL,
  `jenis_akun` enum('A','P','PE','B') NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`akun_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `angsuran` (
  `kode_angsuran` varchar(50) NOT NULL,
  `tgl_angsuran` date NOT NULL,
  `sale_id` int(11) NOT NULL,
  `angsuran_ke` int(11) NOT NULL,
  `jml_bayar` bigint(20) NOT NULL,
  `krg_bayar` bigint(20) NOT NULL,
  PRIMARY KEY (`kode_angsuran`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `angsuran_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `angsuranpemb` (
  `kode_angsuranpemb` varchar(50) NOT NULL,
  `tgl_angsuranpemb` date NOT NULL,
  `pembelian_id` int(11) NOT NULL,
  `angsuranpemb_ke` int(11) NOT NULL,
  `jml_bayar` bigint(20) NOT NULL,
  `krg_bayar` bigint(20) NOT NULL,
  PRIMARY KEY (`kode_angsuranpemb`),
  KEY `pembelian_id` (`pembelian_id`),
  CONSTRAINT `angsuranpemb_ibfk_1` FOREIGN KEY (`pembelian_id`) REFERENCES `pembelian` (`pembelian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `cabang` (
  `cabang_id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_cabang` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`cabang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO cabang VALUES("1","CAB00001","Pusat","085870311400","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","2023-08-09 10:07:46","2023-12-18 22:38:38");
INSERT INTO cabang VALUES("2","CAB00002","Setono","085870311400","Jl. Dr. Sutomo No.1 - 2, Karangmalang, Kec. Pekalongan Tim., Kota Pekalongan, Jawa Tengah","2023-08-09 10:09:10","2023-08-10 11:17:34");



CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price_stock` bigint(20) NOT NULL,
  `price` bigint(20) NOT NULL,
  `qty` int(10) NOT NULL,
  `discount_item` int(11) DEFAULT 0,
  `total_price_stock` bigint(20) NOT NULL,
  `total` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  PRIMARY KEY (`cart_id`),
  KEY `item_id` (`item_id`),
  KEY `user_id` (`user_id`),
  KEY `cabang_id` (`cabang_id`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cart_ibfk_3` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `gambar` varchar(200) DEFAULT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `cabang_id` (`cabang_id`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(150) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `jumlah_stock` int(11) NOT NULL,
  `price_stock` bigint(20) NOT NULL DEFAULT 0,
  `price` bigint(11) DEFAULT NULL,
  `stock` int(10) NOT NULL DEFAULT 0,
  `box` int(11) NOT NULL,
  `image` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `barcode` (`barcode`),
  KEY `category_id` (`category_id`),
  KEY `unit_id` (`unit_id`),
  KEY `cabang_id` (`cabang_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `item_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `item_ibfk_3` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`),
  CONSTRAINT `item_ibfk_4` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`),
  CONSTRAINT `item_ibfk_5` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `jurnal` (
  `jurnal_id` varchar(100) NOT NULL,
  `status_posting` enum('1','0') NOT NULL,
  `date_jurnal` date NOT NULL,
  `pembelian_id` int(11) NOT NULL,
  `pemasukan_id` int(11) NOT NULL,
  `pengeluaran_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`jurnal_id`),
  KEY `sale_id` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `jurnal_detail` (
  `jurnaldetail_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurnal_id` varchar(100) NOT NULL,
  `akun_id` int(11) NOT NULL,
  `debit` bigint(20) NOT NULL,
  `kredit` bigint(20) NOT NULL,
  PRIMARY KEY (`jurnaldetail_id`),
  KEY `jurnal_id` (`jurnal_id`),
  KEY `akun_id` (`akun_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `pemasukan` (
  `pemasukan_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `akun_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nama_pemasukan` varchar(100) NOT NULL,
  `pemasukan_ke` int(11) NOT NULL,
  `jumlah` bigint(20) NOT NULL,
  `kurang` bigint(20) NOT NULL,
  `keterangan` text NOT NULL,
  `date_pemasukan` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pemasukan_id`),
  KEY `akun_id` (`akun_id`),
  KEY `cabang_id` (`cabang_id`),
  KEY `sale_id` (`sale_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `pemasukan_ibfk_1` FOREIGN KEY (`akun_id`) REFERENCES `akun` (`akun_id`),
  CONSTRAINT `pemasukan_ibfk_2` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`),
  CONSTRAINT `pemasukan_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`sale_id`),
  CONSTRAINT `pemasukan_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `pembelian` (
  `pembelian_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice` varchar(50) NOT NULL,
  `no_faktur` varchar(50) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `total_price` bigint(20) NOT NULL,
  `discount` int(11) NOT NULL,
  `final_price` bigint(20) NOT NULL,
  `cash` bigint(20) NOT NULL,
  `kurang_bayar` bigint(20) NOT NULL,
  `remaining` bigint(20) NOT NULL,
  `note` text NOT NULL,
  `date` date NOT NULL,
  `jenistr` enum('T','TF','TFM','TFB','NT','K') NOT NULL,
  `status_transaksi` enum('L','BL','T','R','RE') NOT NULL,
  `jt` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`pembelian_id`),
  KEY `cabang_id` (`cabang_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `pembelian_ibfk_1` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`),
  CONSTRAINT `pembelian_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`),
  CONSTRAINT `pembelian_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `pembelian_detail` (
  `pmbdetail_id` int(11) NOT NULL AUTO_INCREMENT,
  `pembelian_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `discount_item` int(11) NOT NULL,
  `total` bigint(20) NOT NULL,
  `returpemb` enum('0','1') NOT NULL,
  `reversal` enum('0','1') NOT NULL,
  PRIMARY KEY (`pmbdetail_id`),
  KEY `item_id` (`item_id`),
  KEY `pembelian_id` (`pembelian_id`),
  CONSTRAINT `pembelian_detail_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`),
  CONSTRAINT `pembelian_detail_ibfk_2` FOREIGN KEY (`pembelian_id`) REFERENCES `pembelian` (`pembelian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `pengeluaran` (
  `pengeluaran_id` int(11) NOT NULL AUTO_INCREMENT,
  `akun_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nama_pengeluaran` varchar(100) NOT NULL,
  `jumlah` bigint(20) NOT NULL,
  `keterangan` text NOT NULL,
  `date_pengeluaran` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pengeluaran_id`),
  KEY `akun_id` (`akun_id`),
  KEY `cabang_id` (`cabang_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `pengeluaran_ibfk_1` FOREIGN KEY (`akun_id`) REFERENCES `akun` (`akun_id`),
  CONSTRAINT `pengeluaran_ibfk_2` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`),
  CONSTRAINT `pengeluaran_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `pmbcart` (
  `pmbcart_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `discount_item` int(11) DEFAULT 0,
  `total` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  PRIMARY KEY (`pmbcart_id`),
  KEY `item_id` (`item_id`),
  KEY `user_id` (`user_id`),
  KEY `cabang_id` (`cabang_id`),
  CONSTRAINT `pmbcart_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pmbcart_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pmbcart_ibfk_3` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `retur` (
  `kode_retur` varchar(50) NOT NULL,
  `tgl_retur` date NOT NULL,
  `detail_id` int(11) NOT NULL,
  `jml_qty` int(11) NOT NULL,
  `qty_sisa` int(11) NOT NULL,
  `jml_retur` bigint(20) NOT NULL,
  `total_sisa` bigint(20) NOT NULL,
  PRIMARY KEY (`kode_retur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `returpemb` (
  `kode_retur` varchar(50) NOT NULL,
  `tgl_retur` date NOT NULL,
  `pmbdetail_id` int(11) NOT NULL,
  `jml_qty` int(11) NOT NULL,
  `qty_sisa` int(11) NOT NULL,
  `jml_retur` bigint(20) NOT NULL,
  `total_sisa` bigint(20) NOT NULL,
  PRIMARY KEY (`kode_retur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `sale` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice` varchar(50) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `total_price_buy` bigint(20) NOT NULL,
  `final_price_remaining` bigint(20) NOT NULL,
  `total_price` bigint(20) NOT NULL,
  `discount` int(11) NOT NULL,
  `final_price` bigint(20) NOT NULL,
  `cash` bigint(20) NOT NULL,
  `kurang_bayar` bigint(20) NOT NULL,
  `remaining` bigint(20) NOT NULL,
  `note` text NOT NULL,
  `date` date NOT NULL,
  `jenistr` enum('T','TF','TFM','TFB','NT','K') NOT NULL,
  `status_transaksi` enum('L','BL','T','R','RE') NOT NULL,
  `jt` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`sale_id`),
  KEY `cabang_id` (`cabang_id`),
  KEY `customer_id` (`customer_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `sale_ibfk_1` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`),
  CONSTRAINT `sale_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `sale_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `sale_detail` (
  `detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price_stock` bigint(20) NOT NULL,
  `price` bigint(20) NOT NULL,
  `qty` int(10) NOT NULL,
  `discount_item` int(11) NOT NULL,
  `total_price_stock` bigint(20) NOT NULL,
  `total` bigint(20) NOT NULL,
  `retur` enum('0','1') NOT NULL,
  `reversal` enum('0','1') NOT NULL,
  PRIMARY KEY (`detail_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `sale_detail_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`),
  CONSTRAINT `sale_detail_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `stock` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `type` enum('in','out') NOT NULL,
  `detail` varchar(200) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `price_buy` int(11) DEFAULT NULL,
  `qty` int(10) NOT NULL,
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`stock_id`),
  KEY `item_id` (`item_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `stock_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`),
  CONSTRAINT `stock_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `descrip` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(200) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `level` int(1) NOT NULL COMMENT '1:admin, 2:kasir, 3:gudang, 4:pemilik',
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `cabang_id` (`cabang_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`cabang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO user VALUES("1","USR00001","adminussi","14705bed06bda195a0a9008d3f00cfd7a08d0f96","Admin Ussi","PT USSI Batik Pekalongan","1","1","2023-09-06 16:17:52","");
INSERT INTO user VALUES("2","USR00002","admin","21f2b69e63d2107e51e13a2fd4cb59e93a32c942","Admin Toko","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","1","1","2023-09-06 16:17:52","");
INSERT INTO user VALUES("3","USR00003","kasir1","874c0ac75f323057fe3b7fb3f5a8a41df2b94b1d","Kasir 1","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","2","1","2023-09-06 16:17:52","");
INSERT INTO user VALUES("4","USR00004","kasir2","08dfc5f04f9704943a423ea5732b98d3567cbd49","Kasir 2","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","2","1","2023-09-06 16:17:52","");
INSERT INTO user VALUES("5","USR00005","kasir3","dd4fab4a0925326b97aeb5435b0016b1f4ad9863","Kasir 3","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","2","2","2023-09-06 16:17:52","");
INSERT INTO user VALUES("6","USR00006","gudang1","69c790d6e836dbbe1d6417e7d2300f6570e81125","Gudang 1","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","3","1","2023-09-06 16:17:52","");
INSERT INTO user VALUES("7","USR00007","gudang2","c9708f9a1980cd4a606a39388cd5f7297034d2fb","Gudang 2","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","3","2","2023-09-06 16:17:52","");
INSERT INTO user VALUES("8","USR00008","pemilik","1f86485ac9c8b00fb355bd1eb1c86d937f6d457c","Pemilik Toko Sumayyah","Jl. Surabaya No.52, 51129, Pekalongan Utara, Kota Pekalongan, Jawa Tengah","4","1","2023-09-06 16:17:52","");
INSERT INTO user VALUES("10","USR00009","testing1","37becb6cd5d0f5d540386b3db2a91e322c637646","testing1","tes","2","1","2023-12-19 09:42:24","");
INSERT INTO user VALUES("11","USR00010","hasan","37becb6cd5d0f5d540386b3db2a91e322c637646","hasan","testing","2","2","2024-01-09 05:03:35","");

